import org.apache.log4j.{Level, Logger}
import org.apache.spark.rdd
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

object WeatherTest extends Serializable {


  def main(args: Array[String]): Unit = {
    val spark: SparkSession = SparkSession.builder().config("spark.jars","D:\\大数据。\\Scala_project\\Spark01\\out\\artifacts\\Spark01_jar\\Spark01.jar").master("spark://10.102.64.82:7077").appName("Weather").getOrCreate()
    val sc = spark.sparkContext
    val rdd: RDD[String] = sc.textFile("D:\\daaata\\number.txt") //数据文件cndctest.txt
    // 对数据进行处理
    val time1 = System.currentTimeMillis()
      val data1 = rdd.filter(line => {
        var airTemperature = line.substring(89, 92).toInt
        //airTemperature是9999为异常数据，排除，数据过滤
        airTemperature != 9999
      })
        .map(line => {

          val year = line.substring(15, 23)
          var jindu = line.substring(35, 41)
          var weidu = line.substring(29, 34)
          var shidu = line.substring(95, 98).toInt
          var airTemperature = line.substring(89, 92).toInt
          var daqiya = line.substring(99, 104)
          (year, jindu, weidu, airTemperature, shidu, daqiya)
        }
        )
      //利用表格型数据结构DataFrame存储数据
      val df = spark.createDataFrame(data1).toDF("日期", "经度", "纬度", "温度", "湿度", "大气压值")
      df.show()


      println("----------------------------------------")
      //处理数据，只保留日期与温度这两项数据
      val nums = 1.to(100)
      var lag = 1
      for (i <- nums) {
        val data_temp = rdd.filter(line => {
          var airTemperature = line.substring(89, 92).toInt
          airTemperature != 9999
        })
          .map(line => {
            val year = line.substring(15, 23)
            var airTemperature = line.substring(89, 92).toInt
            (year, airTemperature)
          }
          )
        var group = data_temp.groupByKey()
        var group1 = group.map(t => (t._1, t._2.max - t._2.min)) //聚合
        val df1 = spark.createDataFrame(group1).toDF("日期", "温度差")
        var df2 = df1.orderBy(-df1("温度差"))
        println("--------------温差最大的观测点----------------------")
        println("第" + lag + "次运行")
        lag = lag + 1
        df2.head(1).foreach(println)
      }
      println("--------------程序运行时间-------------------------")
      val time2 = System.currentTimeMillis()
      var a = (time2 - time1) / 1000
      println(a + "s")


      // 屏蔽不必要的日志显示终端上

    Logger.getLogger("org.apache.spark").setLevel(Level.ERROR)
    Logger.getLogger("org.eclipse.jetty.server").setLevel(Level.OFF)
  }
}
